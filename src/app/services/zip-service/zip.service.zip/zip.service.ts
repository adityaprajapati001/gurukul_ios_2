import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as JSZip from 'jszip';
import { Filesystem, Directory, Encoding, FileInfo } from '@capacitor/filesystem';
import { LoadingController, ModalController } from '@ionic/angular';
import { IframeModalPage } from 'src/app/modal-controller/iframe-modal/iframe-modal.page';

@Injectable({
  providedIn: 'root'
})
export class ZipService {

  constructor(
    private http: HttpClient, 
    private modalController: ModalController,
    private loadingCtrl: LoadingController
  ) { }

  async downloadAndUnzip(url: string): Promise<void> {
    const loading = await this.loadingCtrl.create({
      message: 'Please Wait...',
    });
    loading.present();
    try {
      // Clear existing directory
      // await this.clearDirectory('unzipped_assets');
     
console.log("URL:",url)
      const zipFileResponse = await this.http.get(url, { responseType: 'arraybuffer' }).toPromise();
      console.log("zipFileResponse:",zipFileResponse)
      // Check if the response is undefined
      if (!zipFileResponse) {
        console.error('Empty response received from the server');
        loading.dismiss();
        return;
      }

      const zipFile: ArrayBuffer = zipFileResponse;
      const zip = await JSZip.loadAsync(zipFile);
      console.log("zipFile:",zipFile)
      console.log("zip:",zip)
      // Iterate through each file in the zip
      for (const filePath of Object.keys(zip.files)) {
        const file = zip.files[filePath];

        // Ensure parent directory exists
        // const parentDirectory = `gurukul/${filePath.substring(0, filePath.lastIndexOf('/'))}`;
        // await this.ensureDirectoryExists(parentDirectory);
        console.log("file:",file)
        // Save the file
        const fileData = await file.async('uint8array');
        console.log("fileData:",fileData)
        await this.saveFile(`gurukul/unzip_files/${filePath}`, fileData);
        
      }

      // Read the contents of the directory after all files are saved
      const directoryContents = await this.readDirectory('gurukul/unzip_files');

      // Find the URI of story.html file
      const storyHtmlUri = directoryContents.find(filename => filename === 'story.html' || 'launcher.html');
      // After saving and reading, open the iframe modal with the story.html URI
      if (storyHtmlUri) {
        const iframeUrl = `gurukul/unzip_files/${storyHtmlUri}`;
        loading.dismiss();
        this.openIframeModal(iframeUrl);

      } else {
        console.error('story.html file not found in the directory');
        loading.dismiss();
      }
    } catch (error) {
      console.error('Error downloading and unzipping file:', error);
      loading.dismiss();
    }
  }

  async ensureDirectoryExists(directoryPath: string): Promise<void> {
    try {
      // Check if the directory exists before attempting to create it
      const directoryExists = await this.checkDirectoryExists(directoryPath);
      if (!directoryExists) {
        await Filesystem.mkdir({
          path: directoryPath,
          directory: Directory.External,
          recursive: true
        });
      }
    } catch (error) {
      console.error('Error creating directory:', error);
    }
  }

  async checkDirectoryExists(directoryPath: string): Promise<boolean> {
    try {
      const result = await Filesystem.stat({
        path: directoryPath,
        directory: Directory.External
      });
      return result.type === 'directory';
    } catch (error) {
      // If an error occurs, assume the directory does not exist
      return false;
    }
  }

  async saveFile(filePath: string, fileData: Uint8Array): Promise<void> {
    console.log("saveFile:",fileData, filePath)
    try {
      const blob = new Blob([fileData]);
      const blobToBase64:any = await this.blobToBase64(blob)
      await Filesystem.writeFile({
        path: filePath,
        data: blobToBase64,
        directory: Directory.External,
        // encoding: Encoding.UTF8,
        recursive: true
      });
    } catch (error) {
      console.error('Error saving file:', error);
    }
  }

  async readDirectory(directoryPath: string): Promise<string[]> {
    try {
      const result = await Filesystem.readdir({
        path: directoryPath,
        directory: Directory.External
      });
      // Map FileInfo objects to file names
      return result.files.map((fileInfo: FileInfo) => fileInfo.name);
    } catch (error) {
      console.error('Error reading directory:', error);
      return [];
    }
  }

  async openIframeModal(iframeSrc: string) {
    const modal = await this.modalController.create({
      component: IframeModalPage,
      componentProps: {
        iframeSrc: iframeSrc,
      }
    });
    return await modal.present();
  }

  async clearDirectory(directoryPath: string): Promise<void> {
    try {
      await Filesystem.rmdir({
        path: directoryPath,
        directory: Directory.External,
        recursive: true // Delete directory and all its contents recursively
      });
      console.log('Directory cleared successfully:', directoryPath);
    } catch (error) {
      console.error('Error clearing directory:', error);
    }
  }

  blobToBase64(blob:Blob) {
    return new Promise((resolve, reject) => {
      const reader:any = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = () => {
        const base64Data = reader.result.split(',')[1];
        resolve(base64Data);
      };
      reader.onerror = (error:any) => {
        reject(error);
      };
    });
  }

}
